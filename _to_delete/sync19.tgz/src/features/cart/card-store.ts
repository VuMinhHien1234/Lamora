"use client";

import { useSyncExternalStore } from "react";
import { GIFT_MESSAGE_MAX } from "@/config/shipping";

// Lời nhắn thiệp + gói quà soạn ở giỏ hàng, lưu ở trình duyệt để trang thanh toán điền sẵn.
const STORAGE_KEY = "lamora-card-v1";

export type CardNote = { message: string; wrap: boolean };

const EMPTY: CardNote = { message: "", wrap: false };
let note: CardNote = EMPTY;
let loaded = false;
const listeners = new Set<() => void>();

function parse(text: string | null): CardNote {
  try {
    const data = JSON.parse(text ?? "null") as Partial<CardNote> | null;
    if (!data || typeof data !== "object") return EMPTY;
    const message = typeof data.message === "string" ? data.message.slice(0, GIFT_MESSAGE_MAX) : "";
    return { message, wrap: data.wrap === true };
  } catch {
    return EMPTY;
  }
}

function load(): void {
  if (loaded) return;
  loaded = true;
  try {
    note = parse(window.localStorage.getItem(STORAGE_KEY));
  } catch {
    note = EMPTY;
  }
}

function save(next: CardNote): void {
  note = next.message === "" && !next.wrap ? EMPTY : next;
  try {
    window.localStorage.setItem(STORAGE_KEY, JSON.stringify(note));
  } catch {
    // Trình duyệt chặn lưu trữ: chỉ giữ trong phiên này.
  }
  for (const listener of listeners) listener();
}

/** Đọc một lần (không theo dõi thay đổi), dùng để điền sẵn form thanh toán. */
export function readCardNote(): CardNote {
  load();
  return note;
}

export function clearCardNote(): void {
  save(EMPTY);
}

export function useCardNote(): CardNote & {
  setMessage: (message: string) => void;
  setWrap: (wrap: boolean) => void;
} {
  const current = useSyncExternalStore(
    (listener) => {
      listeners.add(listener);
      return () => listeners.delete(listener);
    },
    () => {
      load();
      return note;
    },
    () => EMPTY,
  );
  return {
    ...current,
    setMessage: (message) => save({ ...note, message: message.slice(0, GIFT_MESSAGE_MAX) }),
    setWrap: (wrap) => save({ ...note, wrap }),
  };
}

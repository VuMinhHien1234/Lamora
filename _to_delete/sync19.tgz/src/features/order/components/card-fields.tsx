"use client";

import { Controller, type UseFormReturn } from "react-hook-form";
import { Switch } from "@/components/ui/switch";
import { Textarea } from "@/components/ui/textarea";
import { GIFT_MESSAGE_MAX, GIFT_WRAP_FEE } from "@/config/shipping";
import { formatVnd } from "@/lib/money";
import type { CheckoutFormInput } from "../schema";

/** Lời nhắn thiệp và gói quà: luôn hiện, không cần chọn "tặng quà". */
export function CardFields({ form }: { form: UseFormReturn<CheckoutFormInput> }) {
  const { register, control, watch, formState } = form;
  const length = String(watch("giftMessage") ?? "").length;
  return (
    <div className="flex flex-col gap-5">
      <Textarea
        label="Lời nhắn trên thiệp"
        rows={3}
        maxLength={GIFT_MESSAGE_MAX}
        hint={`Tùy chọn · ${length}/${GIFT_MESSAGE_MAX} ký tự. Shop sẽ viết tay vào thiệp kèm theo hoa.`}
        error={formState.errors.giftMessage?.message}
        {...register("giftMessage")}
      />
      <Controller
        control={control}
        name="giftWrap"
        render={({ field }) => (
          <Switch
            checked={Boolean(field.value)}
            onChange={field.onChange}
            label={`Gói quà (+${formatVnd(GIFT_WRAP_FEE)})`}
          />
        )}
      />
    </div>
  );
}

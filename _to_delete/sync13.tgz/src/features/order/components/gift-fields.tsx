"use client";

import { Controller, type UseFormReturn } from "react-hook-form";
import { Input } from "@/components/ui/input";
import { Switch } from "@/components/ui/switch";
import { Textarea } from "@/components/ui/textarea";
import { formatVnd } from "@/lib/money";
import { GIFT_WRAP_FEE } from "@/config/shipping";
import { GIFT_MESSAGE_MAX, type CheckoutFormInput } from "../schema";

type Form = UseFormReturn<CheckoutFormInput>;

function GiftDetails({ form }: { form: Form }) {
  const { register, control, watch, formState } = form;
  const errors = formState.errors;
  const length = String(watch("giftMessage") ?? "").length;
  return (
    <div className="grid gap-5 md:grid-cols-2">
      <Input
        label="Tên người nhận"
        required
        error={errors.recipient?.name?.message}
        {...register("recipient.name")}
      />
      <Input
        label="Số điện thoại người nhận"
        required
        type="tel"
        inputMode="tel"
        error={errors.recipient?.phone?.message}
        {...register("recipient.phone")}
      />
      <div className="md:col-span-2">
        <Textarea
          label="Lời nhắn thiệp"
          rows={3}
          maxLength={GIFT_MESSAGE_MAX}
          hint={`${length}/${GIFT_MESSAGE_MAX} ký tự`}
          error={errors.giftMessage?.message}
          {...register("giftMessage")}
        />
      </div>
      <div className="md:col-span-2">
        <Controller
          control={control}
          name="giftWrap"
          render={({ field }) => (
            <Switch
              checked={Boolean(field.value)}
              onChange={field.onChange}
              label={`Gói quà (+${formatVnd(GIFT_WRAP_FEE)})`}
            />
          )}
        />
      </div>
    </div>
  );
}

export function GiftFields({ form }: { form: Form }) {
  const isGift = form.watch("isGift");
  return (
    <div className="flex flex-col gap-5">
      <Controller
        control={form.control}
        name="isGift"
        render={({ field }) => (
          <Switch checked={field.value} onChange={field.onChange} label="Đây là quà tặng" />
        )}
      />
      {isGift && <GiftDetails form={form} />}
    </div>
  );
}

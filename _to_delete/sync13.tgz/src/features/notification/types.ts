export type NewOrderNotice = {
  id: string;
  code: string;
  customerName: string;
  customerPhone: string;
  wardName: string;
  provinceName: string;
  preferredDeliveryDate: Date | null;
  isGift: boolean;
  giftWrap: boolean;
  paymentMethod: "COD" | "BANK_TRANSFER";
  total: number;
  items: {
    productName: string;
    variantLabel: string | null;
    quantity: number;
    lineTotal: number;
  }[];
};

import { formatVnd } from "@/lib/money";
import { formatDate } from "@/lib/date";
import type { NewOrderNotice } from "./types";

/** Telegram (parse_mode HTML) chỉ cần escape ba ký tự này. */
export function escapeHtml(text: string): string {
  return text.replaceAll("&", "&amp;").replaceAll("<", "&lt;").replaceAll(">", "&gt;");
}

function itemLine(item: NewOrderNotice["items"][number]): string {
  const name = escapeHtml(
    item.variantLabel ? `${item.productName} (${item.variantLabel})` : item.productName,
  );
  return `• ${name} ×${item.quantity} — ${formatVnd(item.lineTotal)}`;
}

function paymentText(method: NewOrderNotice["paymentMethod"]): string {
  return method === "COD" ? "COD (thu tiền khi giao)" : "Chuyển khoản (chưa thanh toán)";
}

/** Tin nhắn "đơn mới" gửi chủ shop (docs/07 mục 4.3). Không chứa địa chỉ chi tiết. */
export function formatNewOrderMessage(order: NewOrderNotice, siteUrl: string): string {
  const lines = [
    `🌸 ĐƠN MỚI · ${order.code}`,
    `Khách: ${escapeHtml(order.customerName)} · ${order.customerPhone}`,
    `Giao: ${escapeHtml(order.wardName)}, ${escapeHtml(order.provinceName)}`,
  ];
  if (order.preferredDeliveryDate) {
    lines.push(`Ngày muốn nhận: ${formatDate(order.preferredDeliveryDate)}`);
  }
  if (order.isGift) lines.push(order.giftWrap ? "🎁 Quà tặng · Có gói quà" : "🎁 Quà tặng");
  lines.push("", ...order.items.map(itemLine), "");
  lines.push(`Tổng: ${formatVnd(order.total)} · ${paymentText(order.paymentMethod)}`);
  lines.push(`Mở đơn: ${siteUrl.replace(/\/$/, "")}/admin/don-hang/${order.id}`);
  return lines.join("\n");
}

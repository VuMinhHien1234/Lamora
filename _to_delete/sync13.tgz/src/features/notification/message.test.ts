import { describe, expect, it } from "vitest";
import { escapeHtml, formatNewOrderMessage } from "./message";
import type { NewOrderNotice } from "./types";

const order: NewOrderNotice = {
  id: "ord1",
  code: "LMR-261005-K7QF",
  customerName: "Nguyễn <b>Hà</b> & Co",
  customerPhone: "0912345678",
  wardName: "Phường Hoàn Kiếm",
  provinceName: "Hà Nội",
  preferredDeliveryDate: new Date("2026-10-08T00:00:00Z"),
  isGift: true,
  giftWrap: true,
  paymentMethod: "BANK_TRANSFER",
  total: 940_000,
  items: [
    {
      productName: "Mẫu đơn hồng phấn",
      variantLabel: "Hồng / Nhỏ",
      quantity: 1,
      lineTotal: 650_000,
    },
    { productName: "Cành hồng lụa trắng", variantLabel: null, quantity: 3, lineTotal: 270_000 },
  ],
};

describe("formatNewOrderMessage", () => {
  const text = formatNewOrderMessage(order, "https://lamora.vn/");

  it("có mã đơn, tổng tiền, hình thức thanh toán và link admin", () => {
    expect(text).toContain("ĐƠN MỚI · LMR-261005-K7QF");
    expect(text).toContain("Tổng: 940.000₫ · Chuyển khoản (chưa thanh toán)");
    expect(text).toContain("Mở đơn: https://lamora.vn/admin/don-hang/ord1");
  });

  it("escape ký tự HTML trong tên khách", () => {
    expect(text).toContain("Nguyễn &lt;b&gt;Hà&lt;/b&gt; &amp; Co");
    expect(text).not.toContain("<b>");
  });

  it("liệt kê sản phẩm, quà tặng, ngày nhận", () => {
    expect(text).toContain("• Mẫu đơn hồng phấn (Hồng / Nhỏ) ×1 — 650.000₫");
    expect(text).toContain("• Cành hồng lụa trắng ×3 — 270.000₫");
    expect(text).toContain("🎁 Quà tặng · Có gói quà");
    expect(text).toContain("Ngày muốn nhận: 08/10/2026");
  });

  it("không lộ địa chỉ chi tiết", () => {
    expect(text).toContain("Phường Hoàn Kiếm, Hà Nội");
  });
});

describe("khác", () => {
  it("escapeHtml", () => expect(escapeHtml("a<b>&")).toBe("a&lt;b&gt;&amp;"));
});

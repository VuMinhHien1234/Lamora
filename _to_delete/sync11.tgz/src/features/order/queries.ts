import { getConfirmation } from "./confirmation-service";
import { readPlacedOrderCode } from "./order-session";
import type { OrderConfirmation } from "./types";

/** 🌐 Thông tin trang cảm ơn. Chỉ xem được ngay sau khi đặt (cookie ký, hết hạn 1 giờ). */
export async function getOrderConfirmation(code: string): Promise<OrderConfirmation | null> {
  return getConfirmation(code, await readPlacedOrderCode());
}

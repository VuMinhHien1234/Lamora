import { cookies } from "next/headers";
import { getEnv } from "@/lib/env";
import { signToken, verifyToken } from "@/lib/signed-token";

const COOKIE_NAME = "lamora_order";
const TTL_SECONDS = 60 * 60;

/** Ghi nhớ trong 1 giờ rằng trình duyệt này vừa đặt đơn `code`. */
export async function rememberPlacedOrder(code: string): Promise<void> {
  (await cookies()).set(
    COOKIE_NAME,
    signToken(code, getEnv().AUTH_SECRET, { ttlSeconds: TTL_SECONDS }),
    {
      httpOnly: true,
      secure: process.env.NODE_ENV === "production",
      sameSite: "lax",
      path: "/",
      maxAge: TTL_SECONDS,
    },
  );
}

/** Mã đơn vừa đặt trên trình duyệt này, hoặc null nếu không có/hết hạn/sai chữ ký. */
export async function readPlacedOrderCode(): Promise<string | null> {
  const token = (await cookies()).get(COOKIE_NAME)?.value;
  return verifyToken(token, getEnv().AUTH_SECRET);
}
